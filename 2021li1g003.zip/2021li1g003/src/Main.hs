{-
Module      : Tarefa5_2021li1g003
Description : Aplicação gráfica completa
Copyright   : Nuno Miguel Barroso Pereira <a91971@alunos.uminho.pt>;
            : Samuel Fernandes Coutinho <a100710@alunos.uminho.pt>;

Módulo para a realização da Tarefa 5 do projeto de LI1 em 2021/2022.
-}

module Main where 

import LI12122
import Tarefa3_2021li1g003
import Tarefa4_2021li1g003
import Mapas
import Graphics.Gloss
import Graphics.Gloss.Interface.IO.Game
import Graphics.Gloss.Interface.Pure.Game
import Graphics.Gloss.Interface.Environment
import Graphics.Gloss.Juicy (loadJuicyPNG)
import System.IO
import Data.Char

type Textura = [(Peca, Picture)]

type TexturaJogador = [((Direcao,Bool),Picture)] 

type Vitoria = Bool

type Estado = Jogo

type Nivel = Int

type Save = IO String

type EstadoGloss = (Bool,Estado,Textura,TexturaJogador,[Key],EstadoMenuGloss,Vitoria,Nivel,Save)

data Menu = Op1 | Op2 | Op3 | Op4
    deriving (Show,Eq)

type EstadoMenu = [(Bool,Menu,(Float,Float))]

type EstadoMenuGloss = (Picture,Picture,Picture,EstadoMenu)

op1C :: (Float,Float)
op1C = (-90,86)

op2C :: (Float,Float)
op2C = (-90,-44)

op3C :: (Float,Float)
op3C = (-90,-169)


displays :: Display
displays = InWindow "Teste" (1536,864) (0,0)

fps :: Int
fps = 20

larguraT :: Float
larguraT = (-768.0)

alturaT :: Float
alturaT = 432.0

-- Tamanho das imagens PNG 32x32
espacamento :: Float
espacamento = 32.0

-- Pictures :: [Pictures] -> Picture

-- Desenha uma imagem recebendo previamente as coordenadas
desenhaPNG :: Float -> Float -> Peca -> Textura -> Picture
desenhaPNG largura altura peca (h:t) 
    | peca == fst h = Translate largura altura (snd h)   
    | otherwise = desenhaPNG largura altura peca t                 

-- tem q andar + espacamento apra a direita
desenhaLinha :: Float -> Float -> [Peca] -> Textura -> [Picture]
desenhaLinha l a (peca : resto) textura = peca_Anterior : peca_Seguinte
    where peca_Anterior = desenhaPNG l a peca textura
          peca_Seguinte = desenhaLinha (l + espacamento) a resto textura
desenhaLinha _ _ _ _ = []

-- tem q andar - espacamento para a baixo
desenhaMapa :: Float -> Float -> Mapa -> Textura -> [Picture]
desenhaMapa l a (linha : resto) textura = linha_Anterior ++ linha_Seguinte
    where linha_Anterior = desenhaLinha l a linha textura
          linha_Seguinte = desenhaMapa l (a - espacamento) resto textura
desenhaMapa _ _ _ _ = []

desenhaJogador :: Jogador -> TexturaJogador -> Picture
desenhaJogador player@(Jogador (x,y) dirJ caixaJ) (((dir,caixa),jogadortext):t)
    | (dirJ == dir && caixaJ == caixa) = Translate (larguraT + (32 * (fromIntegral x))) ((alturaT) - ((fromIntegral y) * 32)) jogadortext
    | otherwise = desenhaJogador player t
        

-- /////////////////// Vitoria
-- Receb um mapa e Coordenadas do Jogador, se o jogador estiver nas mesmas coordenadas da porta == True, otherwise == False
vitoria :: Mapa -> Coordenadas -> Bool
vitoria mapa cords
    | (navigator mapa (0,0) cords) == Porta = True
    | otherwise = False

-- ////////////////////// Menu
desenhaSeta :: Picture -> Picture -> Picture
desenhaSeta menu arrow = Pictures (menu : [arrow])

estadoMenuInicial :: Picture -> Picture -> Picture -> EstadoMenu -> EstadoMenuGloss -- Usando
estadoMenuInicial arrow menu about menuI = (arrow,menu,about,menuI)


desenhaEstado :: EstadoGloss -> IO Picture
desenhaEstado (menuTF,(Jogo mapa jogador),textMapa,textJogador,k,(seta,menu,about,((select,menuO,(x,y)):t)),win,lvl,save) = case menuTF of True -> case select of True -> case lvl of 6 -> return (Translate x y about)
                                                                                                                                                                                      _ -> return (desenhaSeta menu (Translate x y seta)) 
                                                                                                                                                                  False -> desenhaEstado (menuTF,(Jogo mapa jogador),textMapa,textJogador,k,(seta,menu,about,t),win,lvl,save)
                                                                                                                                           False -> case win of False -> return (Translate xF yF (Pictures ((desenhaJogador jogador textJogador) : (desenhaMapa (larguraT) (alturaT) mapa textMapa))))
                                                                                                                                                                True -> case lvl of 1 -> return (Translate (-250) (-25) (Text "Nivel 2"))
                                                                                                                                                                                    2 -> return (Translate (-250) (-25) (Text "Nivel 3"))
                                                                                                                                                                                    3 -> return (Translate (-250) (-25) (Text "Nivel 4"))
                                                                                                                                                                                    4 -> return (Translate (-250) (-25) (Text "Nivel 5"))
                                                                                                                                                                                    5 -> return (Translate (-250) (-25) (Text "Game Over"))
                                                                                                                        
    where xF = ( (-larguraT) - (((fromIntegral (comprimentoMapa mapa)) / 2) * 32) + 16)  -- Centrar o mapa
          yF = ( (-alturaT) + (((fromIntegral (alturaMapa mapa)) / 2) * 32 ) - 16) -- Centrar o mapa

--inputs para movimentos e tal
inputEventos :: Event -> EstadoGloss -> IO EstadoGloss
inputEventos (EventKey tecla Down _ _) (menuTF,jogo,txtM,txtJ,[],m,win,lvl,save) = return (menuTF,jogo,txtM,txtJ,[tecla],m,win,lvl,save) 
inputEventos (EventKey tecla Up _ _) (menuTF,jogo,txtM,txtJ,[_],m,win,lvl,save) = return (menuTF,jogo,txtM,txtJ,[],m,win,lvl,save) 
inputEventos _ estado = return estado


tempoJogo :: Float -> EstadoGloss -> IO EstadoGloss
tempoJogo temp estado@(menuTF,jogo,txtM,txtJ,[],m,win,lvl,save) = return estado
tempoJogo temp estado@(menuTF,jogo,txtM,txtJ,(h:t),menu@(a,m,ab,((select,ops,c):tm)),win,lvl,save) = case menuTF of False -> case win of False -> case h of (SpecialKey KeyUp)    -> return (menuTF,(moveJogador jogo Trepar),txtM,txtJ,t,menu, vitoria (snd (getJogadorInfo jogo)) (fst (getJogadorInfo jogo)),lvl,save)
                                                                                                                                                            (SpecialKey KeyDown)  -> return (menuTF,(moveJogador jogo InterageCaixa),txtM,txtJ,t,menu,vitoria (snd (getJogadorInfo jogo)) (fst (getJogadorInfo jogo)),lvl,save)
                                                                                                                                                            (SpecialKey KeyLeft)  -> return (menuTF,(moveJogador jogo AndarEsquerda),txtM,txtJ,t,menu,vitoria (snd (getJogadorInfo jogo)) (fst (getJogadorInfo jogo)),lvl,save)
                                                                                                                                                            (SpecialKey KeyRight) -> return (menuTF,(moveJogador jogo AndarDireita),txtM,txtJ,t,menu,vitoria (snd (getJogadorInfo jogo)) (fst (getJogadorInfo jogo)),lvl,save)
                                                                                                                                                            _ -> return estado
                                                                                                                                         True -> case lvl of 1 -> return (False,nivel_2,txtM,txtJ,[],menu,False,2,save)
                                                                                                                                                             2 -> return (False,nivel_3,txtM,txtJ,[],menu,False,3,save)
                                                                                                                                                             3 -> return (False,nivel_4,txtM,txtJ,[],menu,False,4,save)
                                                                                                                                                             4 -> return (False,nivel_5,txtM,txtJ,[],menu,False,5,save)
                                                                                                                                                             5 -> return (True,estadoInicial,txtM,txtJ,[],menu,False,1,save)

                                                                                                                    True -> case h of (SpecialKey KeyUp) -> case select of True -> case ops of Op1 -> return (menuTF,jogo,txtM,txtJ,[],estadoMenuInicial a m ab [(False,Op1,op1C),(False,Op2,op2C),(True,Op3,op3C)],win,lvl,save) 
                                                                                                                                                                                               Op2 -> return (menuTF,jogo,txtM,txtJ,[],estadoMenuInicial a m ab [(True,Op1,op1C),(False,Op2,op2C),(False,Op3,op3C)],win,lvl,save)
                                                                                                                                                                                               Op3 -> return (menuTF,jogo,txtM,txtJ,[],estadoMenuInicial a m ab [(False,Op1,op1C),(True,Op2,op2C),(False,Op3,op3C)],win,lvl,save)
                                                                                                                                                                                            

                                                                                                                                                                           False -> (tempoJogo temp (menuTF,jogo,txtM,txtJ,(h:t),(a,m,ab,tm),win,lvl,save)) 

                                                                                                                                      (SpecialKey KeyDown) -> case select of True  -> case ops of Op1 -> return (menuTF,jogo,txtM,txtJ,[],estadoMenuInicial a m ab [(False,Op1,op1C),(True,Op2,op2C),(False,Op3,op3C)],win,lvl,save)
                                                                                                                                                                                                  Op2 -> return (menuTF,jogo,txtM,txtJ,[],estadoMenuInicial a m ab [(False,Op1,op1C),(False,Op2,op2C),(True,Op3,op3C)],win,lvl,save)
                                                                                                                                                                                                  Op3 -> return (menuTF,jogo,txtM,txtJ,[],estadoMenuInicial a m ab [(True,Op1,op1C),(False,Op2,op2C),(False,Op3,op3C)],win,lvl,save)
                                                                                                                                                                                               

                                                                                                                                                                             False -> (tempoJogo temp (menuTF,jogo,txtM,txtJ,(h:t),(a,m,ab,tm),win,lvl,save))

                                                                                                                                      (SpecialKey KeyEnter) ->  case select of True  -> case ops of Op1 -> return (False,jogo,txtM,txtJ,[],menu,win,lvl,save)
                                                                                                                                                                                                    Op2 -> return (False,jogo,txtM,txtJ,[],menu,win,lvl,save)
                                                                                                                                                                                                    Op3 -> return (True,jogo,txtM,txtJ,[],menu,win,6,save)
                                                                                                                                                                                                
                                                                                                                                      _ -> return estado 
                                                                                                    

getJogadorInfo :: Jogo -> (Coordenadas,Mapa)
getJogadorInfo (Jogo m (Jogador cords _ _)) = (cords,m)


-- estado inicial (mapa no inicio)
estadoInicial :: Jogo
estadoInicial = nivel_1

-- adicionar as texturas ao mapa
estadoInicialG :: Bool -> Textura -> TexturaJogador -> EstadoMenuGloss -> Save -> EstadoGloss
estadoInicialG menuTF textura textJogador menu save = (menuTF,estadoInicial, textura, textJogador,[],menu,False,1,save)



main :: IO ()
main = do
    Just caixa <- loadJuicyPNG "Imagens/Box.png"
    Just porta <- loadJuicyPNG "Imagens/Door.png"
    Just bloco <- loadJuicyPNG "Imagens/Wall.png"
    Just vazio <- loadJuicyPNG "Imagens/Vazio.png"
    Just playerD <- loadJuicyPNG "Imagens/Player/CharD.png"
    Just playerE <- loadJuicyPNG "Imagens/Player/CharE.png"
    Just playerDC <- loadJuicyPNG "Imagens/Player/CaixaD.png"
    Just playerEC <- loadJuicyPNG "Imagens/Player/CaixaE.png"
    Just arrow <- loadJuicyPNG "Imagens/Menu/Arrow.png"
    Just menu <- loadJuicyPNG "Imagens/Menu/Menu.png"
    Just about <- loadJuicyPNG "Imagens/Wall.png"
    playIO displays
        white
        fps
        (estadoInicialG True 
            [
                (Vazio,vazio),
                (Bloco,bloco),
                (Caixa,caixa),
                (Porta,porta)
            ] 
            [
                ((Este,False),playerD),
                ((Oeste,False),playerE),
                ((Este,True),playerDC),
                ((Oeste,True),playerEC)
            ]
            (estadoMenuInicial arrow menu about
                [
                    (True,Op1,op1C),
                    (False,Op2,op2C),
                    (False,Op3,op3C)
                ]
            )
            (readFile "Save.txt")    
        )
        desenhaEstado
        inputEventos
        tempoJogo


-- Tentativa 
{-  
guardaEstadoJogo :: EstadoGloss -> IO String
guardaEstadoJogo (_,(Jogo mapa jogador),_,_,_,_,_,lvl,_) = return ((mapaToString mapa) ++ "\n" ++ (jogadorToString jogador))  

mapaToString :: Mapa -> String
mapaToString [] = ";.."
mapaToString (h:t) = mapaToStringAux h ++ ";" ++ mapaToString t

mapaToStringAux :: [Peca] -> String
mapaToStringAux [] = ""
mapaToStringAux (h:t) = pecaToString h : ',' : mapaToStringAux t

jogadorToString :: Jogador -> String
jogadorToString (Jogador (x,y) dir caixa) = (intToDigit x) : '&' : (intToDigit y) : '=' : ((dirToString dir) : '+' : ((boolToString caixa) : ".."))

pecaToString :: Peca -> Char
pecaToString Vazio = 'v'
pecaToString Bloco = 'b'
pecaToString Caixa = 'c'
pecaToString Porta = 'p'

boolToString :: Bool -> Char
boolToString True = 't'
boolToString False = 'f'

dirToString :: Direcao -> Char
dirToString Oeste = 'o'
dirToString Este = 'e'



stringToMapa :: String -> Mapa
stringToMapa [] = []
stringToMapa (hl:hs:t) 
    | hs == ',' = case hl of 'v' -> (Vazio : (head (stringToMapa t) )): (tail (stringToMapa t))
                             'c' -> (Caixa : (head (stringToMapa t) )): (tail (stringToMapa t))
                             'p' -> (Porta : (head (stringToMapa t) )): (tail (stringToMapa t))
                             'b' -> (Bloco : (head (stringToMapa t) )): (tail (stringToMapa t))
    | hs == ';' = case hl of 'v' -> [Vazio] : stringToMapa t
                             'c' -> [Caixa] : stringToMapa t
                             'p' -> [Porta] : stringToMapa t
                             'b' -> [Bloco] : stringToMapa t
    | otherwise = []

stringToJogador :: (Coordenadas,Direcao,Bool) -> IO Jogador
stringToJogador ((x,y),dir,caixa) = return (Jogador (x,y) dir caixa)

stringToJogadorAux :: IO String -> (Coordenadas,Direcao,Bool)
stringToJogadorAux [] = ((0,0),Este,False)
stringToJogadorAux (h:t)  
    | h == '\n' = stringToJogadorAux2 t
    | otherwise = stringToJogadorAux t

stringToJogadorAux2 :: IO String -> (Coordenadas,Direcao,Bool)
stringToJogadorAux2 [] = ((0,0),Este,False)
stringToJogadorAux2 (hl:hs:t)
    | hs == '&' = ((digitToInt hl,ys),ds,cs)
    | hs == '=' = ((xs,digitToInt hl),ds,cs)
    | hs == '+' = case hl of 'e' -> ((xs,ys),Este,cs)
                             'o' -> ((xs,ys),Oeste,cs)
    | hs == '.' = case hl of 't' -> ((xs,ys),ds,True)
                             'f' -> ((xs,ys),ds,False)
        where ((xs,ys),ds,cs) = stringToJogadorAux2 t

 -}