{-
Module      : Tarefa6_2021li1g003
Description : Resolução de um Puzzle
Copyright   : Nuno Miguel Barroso Pereira <a91971@alunos.uminho.pt>;
            : Samuel Fernandes Coutinho <a100710@alunos.uminho.pt>;

Módulo para a realização da Tarefa 6 do projeto de LI1 em 2021/2022.
-}