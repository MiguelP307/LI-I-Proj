{- |
Module      : Tarefa2_2021li1g003
Description : Construção/Desconstrução do mapa
Copyright   : Nuno Miguel Barroso Pereira <a91971@alunos.uminho.pt>;
            : Samuel Fernandes Coutinho <a100710@alunos.uminho.pt>;

Módulo para a realização da Tarefa 2 do projeto de LI1 em 2021/22.
-}
module Tarefa2_2021li1g003 where

import LI12122


{- | A função constroiMapa trata-se da função responsavel para criar o Mapa para o nível do jogo:
@
constroiMapa [] = []
constroiMapa l = constroiMapaAux (ordMapa (completaMapa l) )
@

==Exemplos de utilização:
>>>constroiMapa [(Bloco,(0,2)),(Porta,(0,1)),(Bloco,(1,2)),(BLoco,(2,2))] 
[[Vazio,Vazio,Vazio],[Porta,Vazio,Vazio],[Bloco,Bloco,Bloco]]
>>>ConstroiMapa [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
[[Vazio,Vazio,Vazio,Vazio],[Vazio,Vazio,Vazio,Vazio],[Porta,Vazio,Caixa,Vazio],[Bloco,Bloco,Bloco,Bloco]]
-}
constroiMapa :: [(Peca, Coordenadas)]               -- ^Lista de Peças e as suas coordenadas
                                    -> Mapa         -- ^Mapa Construido
constroiMapa [] = []
constroiMapa l = constroiMapaAux (ordMapa (completaMapa l) )


{- | A função constroiMapaAux trata-se da função auxiliar da função constroiMapa, aqui é onde esta o algoritmo responsável pelo funcionamente final da sua função principal:
@
constroiMapaAux [] = []
constroiMapaAux [(peca,(_,_))] = [[peca]]
constroiMapaAux (p1@(peca,(_,y1)):p2@(_,(_,y2)):t)
    | p1 == p2 = constroiMapaAux (p2:t)
    | y1 /= y2 = [peca] : r
    | otherwise = (peca : (head r)) : tail r
        where r = constroiMapaAux (p2:t)
@

==Exemplos de utilização:
>>>constroiMapaAux [(Bloco,(0,2)),(Porta,(0,1)),(Bloco,(1,2)),(BLoco,(2,2))] 
[[Vazio,Vazio,Vazio],[Porta,Vazio,Vazio],[Bloco,Bloco,Bloco]]
>>>constroiMapaAux [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
[[Vazio,Vazio,Vazio,Vazio],[Vazio,Vazio,Vazio,Vazio],[Porta,Vazio,Caixa,Vazio],[Bloco,Bloco,Bloco,Bloco]]
-}
constroiMapaAux :: [(Peca, Coordenadas)]            -- ^Lista de Peças e as suas coordenadas
                                        -> Mapa     -- ^Mapa Construido
constroiMapaAux [] = []
constroiMapaAux [(peca,(_,_))] = [[peca]]
constroiMapaAux (p1@(peca,(_,y1)):p2@(_,(_,y2)):t)
    | p1 == p2 = constroiMapaAux (p2:t)
    | y1 /= y2 = [peca] : r
    | otherwise = (peca : (head r)) : tail r
        where r = constroiMapaAux (p2:t)



{- | A função ordMapa ordena as Peças e as suas respetivas ordenadas por oderm do X (crescente) e do Y em seguida
@
ordMapa [] = []
ordMapa (h:t) = insertMapa h (ordMapa t)
@

==Exemplos de utilização:
>>>ordMapa [(Bloco,(1,2)),(BLoco,(2,2))(Caixa,(1,0)),(Caixa,(1,1)),(Bloco,(0,2)),(Porta,(0,1))] 
[(Caixa,(1,0)),(Porta,(0,1)),(Caixa,(1,1)),(Bloco,(0,2)),(Bloco,(1,2)),(BLoco,(2,2))] 
>>>ordMapa [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
[(Porta,(0,2)),(Caixa,(2,2)),(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3))]
-}  
ordMapa :: [(Peca,Coordenadas)]                      -- ^ Lista das pecas e ordenadas por organizar       
                            -> [(Peca,Coordenadas)]  -- ^ Lista das pecas e ordenadas organizadas
ordMapa [] = []
ordMapa (h:t) = insertMapa h (ordMapa t)



{- | A função insertMapa instroduz uma Peca e a sua coordenadas de forma organizada numa lista de Pecas e Coordenadas, trata-se da função secundária da ordMapa:
@
insertMapa x [] = [x]
insertMapa pe1@(p1,(x1,y1)) list@(h@(p2,(x2,y2)):t) 
    | (y1 < y2) || (y1 == y2 && x1 < x2) = pe1 : list
    | otherwise = h : insertMapa pe1 t
@

==Exemplos de utilização:
>>>insertMapa (Caixa,(1,1)) [(Bloco,(1,2)),(BLoco,(2,2))(Caixa,(1,0))(Bloco,(0,2)),(Porta,(0,1))] 
[(Caixa,(1,0)),(Porta,(0,1)),(Caixa,(1,1)),(Bloco,(0,2)),(Bloco,(1,2)),(BLoco,(2,2))] 
>>>insertMapa (Bloco,(2,3)) [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
[(Porta,(0,2)),(Caixa,(2,2)),(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3))]
-} 
insertMapa :: (Peca,Coordenadas)                    -- ^ Peça a ser introduzida
                -> [(Peca,Coordenadas)]             -- ^ Lista onde a Peça será introduzida
                    -> [(Peca,Coordenadas)]         -- ^ Lista onde a Peça foi introduzida e ordenada
insertMapa x [] = [x]
insertMapa pe1@(p1,(x1,y1)) list@(h@(p2,(x2,y2)):t) 
    | (y1 < y2) || (y1 == y2 && x1 < x2) = pe1 : list
    | otherwise = h : insertMapa pe1 t


{- | A função completaMapa serve para preencher os espaços "vazios" com a Peca Vazio, ou seja, na lista de Pecas com coordenadas, não precisamos escrever o Vazio, podemos deixar em branco que isto fará com que essas peças sejam colocadas:
@
completaMapa [] = []
completaMapa l = cMA l (xLimite l 0) (yLimite l 0) (xLimite l 0)
@

==Exemplos de utilização:
>>>completaMapa [(Bloco,(0,2)),(Porta,(0,1)),(Bloco,(1,2)),(BLoco,(2,2))] 
[(Vazio,(2,1)),(Vazio,(1,1)),(Vazio,(2,0)),(Vazio,(1,0)),(Vazio,(0,0)),(Bloco,(0,2)),(Porta,(0,1)),(Bloco,(1,2)),(Bloco,(2,2))]
>>>completaMapa[(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
[(Vazio,(3,2)),(Vazio,(1,2)),(Vazio,(3,1)),(Vazio,(2,1)),(Vazio,(1,1)),(Vazio,(0,1)),(Vazio,(3,0)),(Vazio,(2,0)),(Vazio,(1,0)),(Vazio,(0,0)),(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
-}
completaMapa :: [(Peca,Coordenadas)]              -- ^ Lista sem Vazios
                        -> [(Peca,Coordenadas)]   -- ^ Lista com Vazios
completaMapa [] = []
completaMapa l = cMA l (xLimite l 0) (yLimite l 0) (xLimite l 0)


-- Ve se n existe um bloco para uma coordenada e substitui com vazio caso n haja
cMA :: [(Peca,Coordenadas)] -> Int -> Int -> Int -> [(Peca,Coordenadas)]
cMA l _ 0 0 = (Vazio,(0,0)):l
cMA [] _ _ _ = []
cMA l maxX maxY count
    | count >= 0 && (elem (Bloco,(count,maxY)) l || elem (Porta,(count,maxY)) l || elem (Caixa,(count,maxY)) l || elem (Vazio,(count,maxY)) l)  = cMA l maxX maxY (count-1)
    | count < 0 = cMA l maxX (maxY-1) maxX
    | otherwise = (Vazio,(count,maxY)) : cMA l maxX maxY (count-1)


-- Devolve o valor do comprimento do mapa
xLimite :: [(Peca,Coordenadas)] -> Int -> Int
xLimite [] 0 = 0
xLimite [x] m = m
xLimite list@((_,(x1,_)):(_,(x2,_)):t) m
    | x1 <= x2 = xLimite (drop 1 list) x2
    | otherwise = xLimite (drop 1 list) m


--Devolve o valor da altura do mapa
yLimite :: [(Peca,Coordenadas)] -> Int -> Int
yLimite [] 0 = 0
yLimite [x] m = m 
yLimite list@((_,(_,y1)):(_,(_,y2)):t) m
    | y1 <= y2 = yLimite (drop 1 list) y2
    | otherwise = yLimite (drop 1 list) m


{- | A função descontroiMapa faz o contrário da constroi, basicamente transforma um mapa numa lista de peças e coordenadas

@
desconstroiMapa [] = []
desconstroiMapa l = desconstroiMapaAux l 0 0
@

==Exemplos de utilização:
>>>desconstroiMapa [[Vazio,Vazio,Vazio],[Porta,Vazio,Vazio],[Bloco,Bloco,Bloco]]
[(Bloco,(0,2)),(Porta,(0,1)),(Bloco,(1,2)),(BLoco,(2,2))] 
>>>desconstroiMapa [[Vazio,Vazio,Vazio,Vazio],[Vazio,Vazio,Vazio,Vazio],[Porta,Vazio,Caixa,Vazio],[Bloco,Bloco,Bloco,Bloco]]
[[(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
-}
desconstroiMapa :: Mapa                                 -- ^Mapa do jogo
                        -> [(Peca, Coordenadas)]        -- Mapa desconstruido
desconstroiMapa [] = [] 
desconstroiMapa l = desconstroiMapaAux l 0 0


{- | A função descontroiMapaAux é a função secundária da desconstroiMapa e é onde se encontra o algoritmo por trás

@
desconstroiMapaAux [] _ _ = []
desconstroiMapaAux ([]:t) _ county = desconstroiMapaAux t 0 (county+1)
desconstroiMapaAux (h@((peca):te):t) countx county 
    | length h /= 0 = case peca of Vazio -> desconstroiMapaAux (te:t) (countx+1) county
                                   _ -> (peca,(countx,county)) : desconstroiMapaAux (te:t) (countx+1) county
@

==Exemplos de utilização:
>>>desconstroiMapaAux [[Vazio,Vazio,Vazio],[Porta,Vazio,Vazio],[Bloco,Bloco,Bloco]]
[(Bloco,(0,2)),(Porta,(0,1)),(Bloco,(1,2)),(BLoco,(2,2))] 
>>>desconstroiMapaAux [[Vazio,Vazio,Vazio,Vazio],[Vazio,Vazio,Vazio,Vazio],[Porta,Vazio,Caixa,Vazio],[Bloco,Bloco,Bloco,Bloco]]
[[(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
-}

desconstroiMapaAux :: Mapa -> Int -> Int -> [(Peca, Coordenadas)]
desconstroiMapaAux [] _ _ = []
desconstroiMapaAux ([]:t) _ county = desconstroiMapaAux t 0 (county+1)
desconstroiMapaAux (h@((peca):te):t) countx county 
    | length h /= 0 = case peca of Vazio -> desconstroiMapaAux (te:t) (countx+1) county
                                   _ -> (peca,(countx,county)) : desconstroiMapaAux (te:t) (countx+1) county

