{- |
Module      : Tarefa1_2021li1g003
Description : Validação de um potencial mapa
Copyright   : Nuno Miguel Barroso Pereira <a91971@alunos.uminho.pt>;
            : Samuel Fernandes Coutinho <a100710@alunos.uminho.pt>;

Módulo para a realização da Tarefa 1 do projeto de LI1 em 2021/22.
-}
module Tarefa1_2021li1g003 where

import LI12122

{- | A função 'validaPotencialMapa' retorna se o mapa dado é um mapa válido (True) ou não (False). 
     A função pode ser definida da seguinte forma:

@
validaPotencialMapa pecas = (contarportas pecas == 1) && (coordenadasdiferentes pecas) == True && (caixabemposicionada pecas pecas ==True) && (existevazio (mapaordenado pecas) ==True) && (ultimapecaserbloco pecas == True)&& (existechao (coordenadaultimoblocoultimacoluna (mapaordenado pecas)) (mapaordenado pecas) ==True)
@

==Exemplos de utilização:
>>>validaPotencialMapa [(Bloco,(0,2)),(Porta,(0,1)),(BLoco,(1,2))] 
True

>>>validaPotencialMapa [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
True
-}
validaPotencialMapa::[(Peca, Coordenadas)] -- ^ originará o mapa se for válido
                     -> Bool               -- ^ resultado
validaPotencialMapa pecas = (contarportas pecas == 1) && (coordenadasdiferentes pecas) == True && (caixabemposicionada pecas pecas ==True) && (existevazio (mapaordenado pecas) ==True) && (ultimapecaserbloco pecas == True)&& (existechao (coordenadaultimoblocoultimacoluna (mapaordenado pecas)) (mapaordenado pecas) ==True)

{- | A função 'contarportas' retorna o número de portas na lista com as peças que constituirão um mapa. Para ser mapa, esta função terá de retornar o valor 1.
     A função pode ser definida da seguinte forma:
@
contarportas [] = 0
contarportas ((x,_):y)=if x==Porta then 1+contarportas y
                       else contarportas y
@

==Exemplos de utilização:
>>>contarportas [(Bloco,(0,2)),(Porta,(0,1)),(BLoco,(1,2))] 
1
>>>contarportas [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2)),(Porta,(1,2))]
2
-}
contarportas::[(Peca, Coordenadas)] -- ^ peças que constituirão o mapa se for válido e suas coordenadas
              ->Int                 -- ^ número de declaraçṍes de portas 
contarportas [] = 0
contarportas ((x,_):y)=if x==Porta then 1+contarportas y
                       else contarportas y

{- | A função 'coordenada' retorna a coordenada de uma determinada peça.
     A função pode ser definida da seguinte forma:

@
coordenada (_,y) = y
@

==Exemplo de utilização
>>>coordenada (Porta,(1,2))
(1,2)
-}
coordenada::(Peca, Coordenadas) -- ^ Peça 
            ->Coordenadas       -- ^ coordenada respetiva
coordenada (_,y) = y

{- | A função 'listaCoordenadas' retorna a lista de coordenadas do conjunto de peças que constituirão um mapa.
     A função pode ser definida da seguinte forma:

@
listaCoordenadas [] = []
listaCoordenadas ((x,y):z) = y:listaCoordenadas z 
@

==Exemplo de utilização
>>>listaCoordenadas [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
[(0,3),(1,3),(2,3),(3,3),(2,2),(0,2)]
-}
listaCoordenadas::[(Peca, Coordenadas)] -- ^ peças que constituirão o mapa se for válido e suas coordenadas
                  ->[Coordenadas]       -- ^ lista com as coordenadas de todas as peças 
listaCoordenadas [] = []
listaCoordenadas ((x,y):z) = y:listaCoordenadas z 

{- | A função 'coordenadasdiferentes' testa se não existem peças na mesma posição (se não existem peças com a mesma coordenada). 
     A função pode ser definida da seguinte forma:

@
coordenadasdiferentes [] = True
coordenadasdiferentes (h:t) |(coordenada h) `elem` a = False
                            |otherwise = coordenadasdiferentes t
                              where a = listaCoordenadas t
@

==Exemplo de utilização
>>>coordenadasdiferentes [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
True
>>>coordenadasdiferentes [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2)),(Caixa,(1,3))]
False
-}
coordenadasdiferentes::[(Peca, Coordenadas)] -- ^ peças que constituirão o mapa se for válido e suas coordenadas
                       ->Bool                -- ^ resultado
coordenadasdiferentes [] = True
coordenadasdiferentes (h:t) |(coordenada h) `elem` a = False
                            |otherwise = coordenadasdiferentes t
                              where a = listaCoordenadas t

{- | A função 'pecaposicao' determina o tipo de peca que se encontra na coordenada dada.
     A função pode ser definida da seguinte forma:

@
pecaposicao (x,y) [] = Vazio
pecaposicao (x,y) ((x1,x2):z) |x2==(x,y) = x1
                              |otherwise = pecaposicao (x,y) z 
@

==Exemplo de utilização
>>>pecaposicao (1,3) [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2))]
Bloco
-}
pecaposicao::Coordenadas             -- ^ coordenada da qual queremos saber o tipo de peça
             ->[(Peca, Coordenadas)] -- ^ peças que constituirão o mapa se for válido e suas coordenadas
             ->Peca                  -- ^ tipo de peça na coordenada pretendida
pecaposicao (x,y) [] = Vazio
pecaposicao (x,y) ((x1,x2):z) |x2==(x,y) = x1
                              |otherwise = pecaposicao (x,y) z 

{- | A função 'caixabemposicionada' diz se as caixas que estarão no mapa estão bem posicionadas (em cima de outras caixas ou em cima de blocos)
     A função pode ser definida da seguinte forma:

@
caixabemposicionada [] _ = True
caixabemposicionada ((x,(x1,y1)):z) l = if x/= Caixa then caixabemposicionada z l
                                                        else if (pecaposicao (x1,y1 + 1) l == Caixa || pecaposicao (x1,y1 +1) l == Bloco) == True then caixabemposicionada z l
                                                             else False 
@

==Exemplo de utilização
>>>caixabemposicionada [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2)),(Caixa,(3,2))]
True
-}
caixabemposicionada::[(Peca, Coordenadas)]   -- ^ peças que constituirão o mapa se for válido e suas coordenadas 
                     ->[(Peca, Coordenadas)] -- ^ a lista anterior
                     ->Bool                  -- ^ resultado
caixabemposicionada [] _ = True
caixabemposicionada ((x,(x1,y1)):z) l = if x/= Caixa then caixabemposicionada z l
                                                        else if (pecaposicao (x1,y1 + 1) l == Caixa || pecaposicao (x1,y1 +1) l == Bloco) == True then caixabemposicionada z l
                                                             else False 

{- | A função 'insere' insere uma peça de modo a ficar num local em que a coordenada dessa peça é imediatamente a seguir à coordenada da peça anterior.
     A função pode ser definida da seguinte forma:

@
insere x [] = [x]
insere (x2,(x3,y3)) ((x,(x1,y1)):z) |x3 < x1 = ((x2,(x3,y3)):((x,(x1,y1)):z))
                                    |x3 == x1 && y3 < y1 = ((x2,(x3,y3)):((x,(x1,y1)):z))
                                    |otherwise = (x,(x1,y1)):(insere (x2,(x3,y3)) z)
@

==Exemplo de utilização
>>>insere (Caixa,(3,1)) [(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2)),(Caixa,(3,2))]
[(Bloco,(0,3)),(Bloco,(1,3)),(Bloco,(2,3)),(Bloco,(3,3)),(Caixa,(2,2)),(Porta,(0,2)),(Caixa,(3,1)),(Caixa,(3,2))]
-}
insere:: (Peca, Coordenadas)       -- ^ peça a ser inserida
         -> [(Peca, Coordenadas)] -- ^ conjunto de peças e coordenadas onde a peça deve ser acrescentada
         -> [(Peca, Coordenadas)] -- ^ conjunto de peças e coordenadas com a peça indicada já inserida
insere x [] = [x]
insere (x2,(x3,y3)) ((x,(x1,y1)):z) |x3 < x1 = ((x2,(x3,y3)):((x,(x1,y1)):z))
                                    |x3 == x1 && y3 < y1 = ((x2,(x3,y3)):((x,(x1,y1)):z))
                                    |otherwise = (x,(x1,y1)):(insere (x2,(x3,y3)) z)

{- | A função 'mapaordenado' faz com que as peças fiquem posicionadas de forma a que as coordenadas destas fiquem ordenadas.
     A função pode ser definida da seguinte forma:

@
mapaordenado [] = []
mapaordenado ((x,(x1,y1)):y) = insere (x,(x1,y1)) (mapaordenado y)
@

==Exemplo de utilização
>>>mapaordenado [(Bloco,(4,3)),(Bloco,(4,2)),(Bloco,(4,0)),(Bloco,(4,1)),(Caixa,(2,2)),(Bloco,(2,3)),(Bloco,(3,3)),(Porta,(0,1)),(Bloco,(0,3)),(Bloco,(0,2)),(Bloco,(1,3))]
[(Porta,(0,1)),(Bloco,(0,2)),(Bloco,(0,3)),(Bloco,(1,3)),(Caixa,(2,2)),(Bloco,(2,3)),(Bloco,(3,3)),(Bloco,(4,0)),(Bloco,(4,1)),(Bloco,(4,2)),(Bloco,(4,3))]
-}
mapaordenado::[(Peca, Coordenadas)]   -- ^ conjunto de peças e coordenadas não ordenadas
              ->[(Peca, Coordenadas)] -- ^ conjunto de peças e coordenadas ordenadas
mapaordenado [] = []
mapaordenado ((x,(x1,y1)):y) = insere (x,(x1,y1)) (mapaordenado y)

{- | A função 'existevazio' testa se existe algum espaço vazio no futuro mapa. Para executar esta função a lista [(Peca, Coordenadas)]  de input tem de estar ordenada.
     A função pode ser definida da seguinte forma:

@
existevazio [(x,(x1,y1)),(x2,(x3,y3))] |x1==x3 && ((y3-y1) /= 1) = True
                                       |x1/=x3 && (y3/=0) = True
                                       |otherwise =False
existevazio ((x,(x1,y1)):(x2,(x3,y3)):y) |x1==x3 && ((y3-y1) /= 1) = True
                                         |x1/=x3 && (y3/=0) = True
                                         |otherwise = existevazio ((x2,(x3,y3)):y)
@

==Exemplo de utilização
>>>existevazio [(Porta,(0,1)),(Bloco,(0,2)),(Bloco,(0,3)),(Bloco,(1,3)),(Caixa,(2,2)),(Bloco,(2,3)),(Bloco,(3,3)),(Bloco,(4,0)),(Bloco,(4,1)),(Bloco,(4,2)),(Bloco,(4,3))]
True
-}
existevazio::[(Peca, Coordenadas)] -- ^ lista testada para ver se tem espaço vazio
             ->Bool                -- ^ resultado
existevazio [(x,(x1,y1)),(x2,(x3,y3))] |x1==x3 && ((y3-y1) /= 1) = True
                                       |x1/=x3 && (y3/=0) = True
                                       |otherwise =False
existevazio ((x,(x1,y1)):(x2,(x3,y3)):y) |x1==x3 && ((y3-y1) /= 1) = True
                                         |x1/=x3 && (y3/=0) = True
                                         |otherwise = existevazio ((x2,(x3,y3)):y)


--antes de executar estas funções, executar mapaordenado
{- | A função 'coordenadaultimoblocoultimacoluna' devolve a coordenada do ultimo Bloco da lista. A lista de input tem de estar ordenada.
     A função pode ser definida da seguinte forma:

@
coordenadaultimoblocoultimacoluna l = last (listaCoordenadas l)
@

==Exemplo de utilização
>>>coordenadaultimoblocoultimacoluna [(Porta,(0,1)),(Bloco,(0,2)),(Bloco,(0,3)),(Bloco,(1,3)),(Caixa,(2,2)),(Bloco,(2,3)),(Bloco,(3,3)),(Bloco,(4,0)),(Bloco,(4,1)),(Bloco,(4,2)),(Bloco,(4,3))]
(4,3)
-}
coordenadaultimoblocoultimacoluna::[(Peca, Coordenadas)] -- ^ lista de peças e coordenadas respetivas que constituirão o mapa se este for válido.
                                   ->Coordenadas         -- ^ coordenada do último bloco da última coluna que constituirá o mapa
coordenadaultimoblocoultimacoluna l = last (listaCoordenadas l)

{- | A função 'ultimapecaserbloco' testa se a última peça da última coluna é um bloco. A lista de input tem de estar ordenada.
     A função pode ser definida da seguinte forma:

@
ultimapecaserbloco l = (pecaposicao (coordenadaultimoblocoultimacoluna l) l  )==Bloco
@

==Exemplo de utilização 
>>>ultimapecaserbloco [(Porta,(0,1)),(Bloco,(0,2)),(Bloco,(0,3)),(Bloco,(1,3)),(Caixa,(2,2)),(Bloco,(2,3)),(Bloco,(3,3)),(Bloco,(4,0)),(Bloco,(4,1)),(Bloco,(4,2)),(Bloco,(4,3))]
True
-}
ultimapecaserbloco::[(Peca, Coordenadas)] -- ^ lista de peças e coordenadas respetivas que constituirão o mapa se este for válido. 
                    ->Bool                -- ^ resultado
ultimapecaserbloco l = (pecaposicao (coordenadaultimoblocoultimacoluna l) l  )==Bloco

{- | A função 'existechao' testa se existe um chão contínuo no mapa. A coordenada de input tem se ser a coordenada do ultimo bloco da ultima coluna e a lista de input tem se estar ordenada.
     A função pode ser definida da seguinte forma:

@
existechao (0,_) _ = True
existechao (x,y) (x2:z) |(pecaposicao (x-1,y) (x2:z) == Bloco)  = existechao (x-1,y) (x2:z)
                        |(pecaposicao (x-1,y-1) (x2:z)== Bloco)  = existechao (x-1,y-1) (x2:z)
                        |(pecaposicao (x-1,y+1) (x2:z) == Bloco)  = existechao (x-1,y+1) (x2:z)
                        |otherwise                         = False
@

==Exemplo de utilização
>>>existechao [(Porta,(0,1)),(Bloco,(0,2)),(Bloco,(0,3)),(Bloco,(1,3)),(Caixa,(2,2)),(Bloco,(2,3)),(Bloco,(3,3)),(Bloco,(4,0)),(Bloco,(4,1)),(Bloco,(4,2)),(Bloco,(4,3))]
True
-}
existechao::Coordenadas             -- ^ coordenada do último bloco da última coluna
            ->[(Peca, Coordenadas)] -- ^ lista de peça e coordenadas que constituirão o mapa se este for válido
            ->Bool                  -- ^ resultado
existechao (0,_) _ = True
existechao (x,y) (x2:z) |(pecaposicao (x-1,y) (x2:z) == Bloco)  = existechao (x-1,y) (x2:z)
                        |(pecaposicao (x-1,y-1) (x2:z)== Bloco)  = existechao (x-1,y-1) (x2:z)
                        |(pecaposicao (x-1,y+1) (x2:z) == Bloco)  = existechao (x-1,y+1) (x2:z)
                        |otherwise                         = False