{- |
Module      : Tarefa4_2021li1g003
Description : Movimentação do personagem
Copyright   : Nuno Miguel Barroso Pereira <a91971@alunos.uminho.pt>;
            : Samuel Fernandes Coutinho <a100710@alunos.uminho.pt>;

Módulo para a realização da Tarefa 4 do projeto de LI1 em 2021/22.
-}
module Tarefa4_2021li1g003 where

import LI12122
import Tarefa3_2021li1g003


-- TO DO
moveJogador :: Jogo -> Movimento -> Jogo -- (Jogo Mapa (Jogador Coordenadas Direção Caixa) (Movimento))
{- moveJogador jogo movimento = undefined -}

-- Andar Esquerda
moveJogador game@(Jogo mapa (Jogador (x,y) dir caixa)) AndarEsquerda
  | ( validarMov && (navegar1_1 /= Vazio)) && (not caixa)= (Jogo mapa (Jogador (x-1,y) Oeste caixa)) -- Andar Normalmente
  | ( validarMov && (navegar1_1 == Vazio)) && (not caixa) = ((Jogo mapa (Jogador (x-1,y + int_queda) Oeste caixa))) -- Queda ao andar
  | ( validarMov && (navegar1_1 /= Vazio)) && caixa = (Jogo movCaixaEsq (Jogador (x-1,y) Oeste caixa)) 
  | ( validarMov && (navegar1_1 == Vazio)) && caixa = ((Jogo queda_Caixa (Jogador (x-1,y + int_queda) Oeste caixa)))
  | otherwise = (Jogo mapa (Jogador (x,y) Oeste caixa)) -- Fica no sitio e so altera a direção
    where int_queda = queda mapa (0,0) (x-1,y)
          validarMov = (valMov AndarEsquerda (navigator mapa (0,0) (x-1,y)) game)
          navegar1_1 = (navigator mapa (0,0) (x-1,y+1))
          movCaixaEsq = movCaixa mapa (0,0) (x,y) Oeste
          queda_Caixa = quedaCaixa mapa (0,0) (x,y) Oeste int_queda AndarEsquerda

-- Andar Direita
moveJogador game@(Jogo mapa (Jogador (x,y) dir caixa)) AndarDireita
  | ( validarMov && (navegar1_1 /= Vazio)) && (not caixa) = (Jogo mapa (Jogador (x+1,y) Este caixa))               -- Andar Normalmente
  | ( validarMov && (navegar1_1 == Vazio)) && (not caixa) = ((Jogo mapa (Jogador (x+1,y + int_queda) Este caixa))) -- Queda ao andar
  | ( validarMov && (navegar1_1 /= Vazio)) && caixa = (Jogo movCaixaDir (Jogador (x+1,y) Este caixa))               -- Andar Normalmente c/ caixa
  | ( validarMov && (navegar1_1 == Vazio)) && caixa = ((Jogo queda_Caixa (Jogador (x+1,y + int_queda) Este caixa))) -- Queda ao andar c/caixa
  | otherwise = (Jogo mapa (Jogador (x,y) Este caixa)) -- Fica no sitio e so altera a direção
    where int_queda = queda mapa (0,0) (x+1,y)
          validarMov = (valMov AndarDireita (navigator mapa (0,0) (x+1,y)) game)
          navegar1_1 = (navigator mapa (0,0) (x+1,y+1))
          movCaixaDir = movCaixa mapa (0,0) (x,y) Este
          queda_Caixa = quedaCaixa mapa (0,0) (x,y) Este int_queda AndarDireita

-- Subir
moveJogador game@(Jogo mapa (Jogador (x,y) dir caixa)) Trepar
  | validarMovDir && (dir == Este) && (not caixa ) = (Jogo mapa (Jogador (x+1,y-1) Este caixa))   -- Trepa para a Direita
  | validarMovEsq && (dir == Oeste) && (not caixa) = (Jogo mapa (Jogador (x-1,y-1) Oeste caixa)) -- Trepa para a Esquerda
  | validarMovDir && (dir == Este) && caixa = (Jogo sobeCaixaDir (Jogador (x+1,y-1) Este caixa))
  | validarMovEsq && (dir == Oeste) && caixa = (Jogo sobeCaixaEsq (Jogador (x-1,y-1) Oeste caixa))
  | otherwise = (Jogo mapa (Jogador (x,y) dir caixa))                             -- Não trepa para lado nenhum e mantem a direção
    where validarMovDir = valMov Trepar (navigator mapa (0,0) (x+1,y)) game
          validarMovEsq = valMov Trepar (navigator mapa (0,0) (x-1,y)) game
          sobeCaixaDir = sobeCaixa mapa (0,0) (x,y) Este
          sobeCaixaEsq = sobeCaixa mapa (0,0) (x,y) Oeste
          


moveJogador game@(Jogo mapa (Jogador (x,y) dir caixa)) InterageCaixa
  | validarIntDir && (dir == Este) && (not caixa) && (pecaDir == Caixa) = (Jogo pegaCaixa (Jogador (x,y) dir True)) -- Pegar caixa a Direita
  | validarIntEsq && (dir == Oeste) && (not caixa) && (pecaEsq == Caixa) = (Jogo pegaCaixa (Jogador (x,y) dir True)) -- Pegar caixa a Esquerda
  | validarIntDir && (dir == Este) && (navegar1_1D /= Vazio) && caixa && (pecaDir == Vazio) = (Jogo pousaCaixa (Jogador (x,y) dir False)) -- Pousar a caixa a Direita c/ chao
  | validarIntEsq && (dir == Oeste) && (navegar1_1E /= Vazio) && caixa && (pecaEsq == Vazio) = (Jogo pousaCaixa (Jogador (x,y) dir False)) -- Pousar a caixa a esq c/ chao
  | validarIntDir && (dir == Este) && (navegar1_1D == Vazio) && caixa && (pecaDir == Vazio) = (Jogo queda_CaixaD (Jogador (x,y) Este False)) -- Pousar a caixa a Direita s/ chao
  | validarIntEsq && (dir == Oeste) && (navegar1_1E == Vazio) && caixa && (pecaEsq == Vazio) = (Jogo queda_CaixaE (Jogador (x,y) Oeste False)) -- Pousar a caixa a esq s/ chao
  | validarIntDir && (dir == Este) && caixa && ((pecaDir == Bloco) || (pecaDir == Caixa))  = (Jogo pousaCaixa_BC (Jogador (x,y) dir False)) -- Pousar a caixa a Direita c/ chao
  | validarIntEsq && (dir == Oeste) && caixa && ((pecaEsq == Bloco) || (pecaEsq == Caixa)) = (Jogo pousaCaixa_BC (Jogador (x,y) dir False)) -- Pousar a caixa a esq c/ chao
  | otherwise = (Jogo mapa (Jogador (x,y) dir caixa))
    where validarIntDir = valMov InterageCaixa (navigator mapa (0,0) (x+1,y)) game
          validarIntEsq = valMov InterageCaixa (navigator mapa (0,0) (x-1,y)) game
          pecaDir = navigator mapa (0,0) (x+1,y)
          pecaEsq = navigator mapa (0,0) (x-1,y)
          pegaCaixa = posCaixa mapa (0,0) (x,y) dir (Caixa,Vazio)
          pousaCaixa = posCaixa mapa (0,0) (x,y) dir (Vazio,Caixa)
          navegar1_1D = (navigator mapa (0,0) (x+1,y+1))
          navegar1_1E = (navigator mapa (0,0) (x-1,y+1))
          int_quedaD = queda mapa (0,0) (x+1,y)
          int_quedaE = queda mapa (0,0) (x-1,y)
          queda_CaixaD = quedaCaixa mapa (0,0) (x,y+1) Este int_quedaD InterageCaixa
          queda_CaixaE = quedaCaixa mapa (0,0) (x,y+1) Oeste int_quedaE InterageCaixa
          pousaCaixa_BC = posCaixa2 mapa (0,0) (x,y) dir

-- Move jogador para Interagir

-- Função que verifica se é possivel realizar um movimento com a Peca que esta do lado dele
valMov :: Movimento -> Peca -> Jogo -> Bool
valMov mov peca (Jogo mapa (Jogador (x,y) dir caixa)) =case peca of Porta -> case mov of AndarEsquerda -> True
                                                                                         AndarDireita -> True
                                                                                         _ -> False
                                                                    Bloco -> case mov of Trepar -> case caixa of False -> case dir of Oeste -> (((navigator mapa (0,0) (x-1,y-1) == Vazio) || ((navigator mapa (0,0) (x-1,y-1) == Porta))) && ((navigator mapa (0,0) (x,y-1)) == Vazio)) --Trepar sem caixa
                                                                                                                                      Este -> (((navigator mapa (0,0) (x+1,y-1) == Vazio) || ((navigator mapa (0,0) (x-1,y-1) == Porta))) && ((navigator mapa (0,0) (x,y-1)) == Vazio))
                                                                                                                 True -> case dir of Oeste -> ((navigator mapa (0,0) (x-1,y-2) == Vazio) && ((navigator mapa (0,0) (x,y-2)) == Vazio) && ((navigator mapa (0,0) (x-1,y-1) == Vazio) || ((navigator mapa (0,0) (x-1,y-1) == Porta))))
                                                                                                                                     Este -> ((navigator mapa (0,0) (x+1,y-2) == Vazio) && ((navigator mapa (0,0) (x,y-2)) == Vazio) && ((navigator mapa (0,0) (x+1,y-1) == Vazio) || ((navigator mapa (0,0) (x-1,y-1) == Porta))))

                                                                                         InterageCaixa -> case caixa of True -> case dir of Oeste -> (navigator mapa (0,0) (x-1,y-1) == Vazio) 
                                                                                                                                            Este -> (navigator mapa (0,0) (x+1,y-1) == Vazio)
                                                                                                                        False -> False
                                                                                         _ -> False 
                                                                    Caixa -> case mov of AndarDireita -> False 
                                                                                         AndarEsquerda -> False
                                                                                         Trepar -> case caixa of False -> case dir of Oeste -> ((navigator mapa (0,0) (x-1,y-1) == Vazio) && ((navigator mapa (0,0) (x,y-1)) == Vazio)) --Trepar sem caixa
                                                                                                                                      Este -> ((navigator mapa (0,0) (x+1,y-1) == Vazio) && ((navigator mapa (0,0) (x,y-1)) == Vazio))
                                                                                                                 True -> case dir of Oeste -> ((navigator mapa (0,0) (x-1,y-2) == Vazio) && ((navigator mapa (0,0) (x,y-2)) == Vazio)) -- Treparcom caixa
                                                                                                                                     Este -> ((navigator mapa (0,0) (x+1,y-2) == Vazio) && ((navigator mapa (0,0) (x,y-2)) == Vazio))

                                                                                         InterageCaixa -> case caixa of False -> case dir of Oeste -> ((navigator mapa (0,0) (x-1,y-1) == Vazio) && ((navigator mapa (0,0) (x,y-1)) == Vazio))
                                                                                                                                             Este -> ((navigator mapa (0,0) (x+1,y-1) == Vazio) && ((navigator mapa (0,0) (x,y-1)) == Vazio))
                                                                                                                        True -> case dir of Oeste -> (navigator mapa (0,0) (x-1,y-1) == Vazio) 
                                                                                                                                            Este -> (navigator mapa (0,0) (x+1,y-1) == Vazio)

                                                                    Vazio -> case mov of AndarEsquerda -> case caixa of False -> True
                                                                                                                        True -> (navigator mapa (0,0) (x-1,y-1)) == Vazio -- Ve se pode andar com a caixa para a esquerda

                                                                                         AndarDireita -> case caixa of False -> True
                                                                                                                       True -> (navigator mapa (0,0) (x+1,y-1)) == Vazio -- Ve se pode andar com a caixa para a direita

                                                                                         InterageCaixa -> case dir of Oeste ->  (navigator mapa (0,0) (x-1,y-1)) == Vazio -- Ve se pode pegar ou pousar a caixa no CHAO!
                                                                                                                      Este -> (navigator mapa (0,0) (x+1,y-1)) == Vazio -- Ve se pode pegar ou pousar a caixa no CHAO!
                                                                                         Trepar -> False 
                                                                      


--Queda (conta o numero de "blocos" que o player vai cair)
queda :: Mapa -> Coordenadas -> Coordenadas -> Int
queda map (x,y) (xp,yp)
  | navigator map (0,0) (xp,yp+1) == Vazio = 1 + queda map (0,0) (xp, yp+1)
  | otherwise = 0

quedaCaixa :: Mapa -> Coordenadas -> Coordenadas -> Direcao -> Int -> Movimento -> Mapa
quedaCaixa [] _ _ _ _ _ = [] 
quedaCaixa ([]:te) _ _ _ _ _ = [[]]
quedaCaixa mapa@(((peca):ti):te) (x,y) (xp,yp) dir quedaC mov
  | x == xp && y == (yp-2) && (mov == InterageCaixa ) = (Vazio : cabeça) : next
  | x == xp && y == (yp-1) && (mov /= InterageCaixa) = (Vazio : cabeça) : next
  | x == (xp-1) && y == (yp+(quedaC-1)) && (dir == Oeste) = (Caixa : cabeça) : next
  | x == (xp+1) && y == (yp+(quedaC-1)) && (dir == Este) = (Caixa : cabeça) : next
  | ti /= [] = (peca : cabeça) : next                    
  | otherwise = [peca] : next                              
    where next = quedaCaixa te (0,y+1) (xp,yp) dir quedaC mov
          cabeça = head (quedaCaixa (ti:te) (x+1,y) (xp,yp) dir quedaC mov)
          

-- Pegar e pousar no chao
posCaixa :: Mapa -> Coordenadas -> Coordenadas -> Direcao -> (Peca,Peca)-> Mapa  --(Caixa,Vazio) -> Pegar   (Vazio,Caixa) -> Pousar
posCaixa [] _ _ _ _ = []   --(0,0) (4 , 5)
posCaixa (((peca):ti):te) (x,y) (xp,yp) dir (p1,p2)
  | x == xp && y == (yp-1) = (p1 : ti) : next
  | x == (xp-1) && y == yp && dir == Oeste = (p2 : ti) : te
  | x == (xp+1) && y == yp && dir == Este = (p2 : ti) : te
  | ti /= [] = (peca : head (posCaixa (ti:te) (x+1,y) (xp,yp) dir (p1,p2))) : next                    
  | otherwise = [peca] : next                              
    where next = posCaixa te (0,y+1) (xp,yp) dir (p1,p2)

posCaixa2 :: Mapa -> Coordenadas -> Coordenadas -> Direcao -> Mapa  
posCaixa2 [] _ _ _  = []  
posCaixa2 ([]:te) _ _ _ = [[]]
posCaixa2 (((peca):ti):te) (x,y) (xp,yp) dir
  | x == xp && y == (yp-1) = (Vazio : cabeça) : next
  | x == (xp-1) && y == (yp-1) && (dir == Oeste )= (Caixa : cabeça) : next
  | x == (xp+1) && y == (yp-1) && (dir == Este) = (Caixa : cabeça) : next
  | ti /= [] = (peca : cabeça) : next                    
  | otherwise = [peca] : next                              
    where next = posCaixa2 te (0,y+1) (xp,yp) dir 
          cabeça = head (posCaixa2 (ti:te) (x+1,y) (xp,yp) dir)
  

movCaixa :: Mapa -> Coordenadas -> Coordenadas -> Direcao -> Mapa
movCaixa [] _ _ _  = [] 
movCaixa ([]:te) _ _ _ = [[]]
movCaixa (((peca):ti):te) (x,y) (xp,yp) dir
  | x == xp && y == (yp-1) = (Vazio : cabeça) : next
  | x == (xp-1) && y == (yp-1) && (dir == Oeste) = (Caixa : cabeça) : next
  | x == (xp+1) && y == (yp-1) && (dir == Este) = (Caixa : cabeça) : next
  | ti /= [] = (peca : cabeça) : next                    
  | otherwise = [peca] : next                              
    where next = movCaixa te (0,y+1) (xp,yp) dir
          cabeça = head (movCaixa (ti:te) (x+1,y) (xp,yp) dir)


sobeCaixa :: Mapa -> Coordenadas -> Coordenadas -> Direcao -> Mapa
sobeCaixa [] _ _ _  = [] 
sobeCaixa ([]:te) _ _ _ = [[]]
sobeCaixa (((peca):ti):te) (x,y) (xp,yp) dir
  | x == xp && y == (yp-1) = (Vazio : cabeça) : next
  | x == (xp-1) && y == (yp-2) && (dir == Oeste) = (Caixa : cabeça) : next
  | x == (xp+1) && y == (yp-2) && (dir == Este) = (Caixa : cabeça) : next
  | ti /= [] = (peca : cabeça) : next                    
  | otherwise = [peca] : next                              
    where next = sobeCaixa te (0,y+1) (xp,yp) dir
          cabeça = head (sobeCaixa (ti:te) (x+1,y) (xp,yp) dir)


-- TO DO
correrMovimentos :: Jogo -> [Movimento] -> Jogo
correrMovimentos game [] = game
correrMovimentos game (mov:t) = correrMovimentos (moveJogador game mov) t 

