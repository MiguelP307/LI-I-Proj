{- |
Module      : Tarefa3_2021li1g003
Description : Representação textual do jogo
Copyright   : Nuno Miguel Barroso Pereira <a91971@alunos.uminho.pt>;
            : Samuel Fernandes Coutinho <a100710@alunos.uminho.pt>;

Módulo para a realização da Tarefa 3 do projeto de LI1 em 2021/22.
-}
module Tarefa3_2021li1g003 where

import LI12122
import Tarefa2_2021li1g003


instance Show Jogo where
 show (Jogo mapa (Jogador (x,y) direcao caixa)) = (showJogo (Jogo mapa (Jogador (x,y) direcao caixa))) 


{- | A função 'showJogo' mostra o jogo. Tem de ser executada a função print no resultado desta função para ser possível a visualização do mapa em si.
     A função pode ser definida da seguinte forma:

@
showJogo (Jogo mapa (Jogador (x,y) direcao caixa))= (colocaJogador (ordMapa (cMA (desconstroiMapa mapa) (comprimentoMapa mapa) (alturaMapa mapa) (comprimentoMapa mapa))) (Jogador (x,y) direcao caixa))
@

==Exemplos de utilização
>>>showJogo (Jogo [[Vazio,Vazio,Vazio,Vazio,Bloco],[Porta,Vazio,Vazio,Vazio,Bloco],[Bloco,Vazio,Caixa,Vazio,Bloco],[Bloco,Bloco,Bloco,Bloco,Bloco]] (Jogador (3,2) Este True))
    X
P  CX
X C>X
XXXXX
>>>showJogo (Jogo [[Vazio,Vazio,Vazio,Vazio,Bloco],[Porta,Vazio,Vazio,Vazio,Bloco],[Bloco,Vazio,Caixa,Vazio,Bloco],[Bloco,Bloco,Bloco,Bloco,Bloco]] (Jogador (3,2) Oeste False))
    X
P   X
X C<X
XXXXX
-}
showJogo::Jogo       -- ^ Jogo com as características de momento
          ->String   -- ^ Jogo mostrado ao jogador
showJogo (Jogo mapa (Jogador (x,y) direcao caixa))= (colocaJogador (ordMapa (cMA (desconstroiMapa mapa) (comprimentoMapa mapa) (alturaMapa mapa) (comprimentoMapa mapa))) (Jogador (x,y) direcao caixa))

{- | A função 'coordenadaInicialPossivel' testa se uma coordenada dada pelo Jogador é uma coordenada possível para a coordenada inicial para colocar o personagem (este não carrega uma caixa). Mapa é originado com constroiMapa da tarefa2 e Coordenadas é uma coordenada escolhida pelo Jogador.
     A função pode ser definida da seguinte forma:

@
coordenadaInicialPossivel [] _ = False
coordenadaInicialPossivel ((x:y):z) (x1,y1) =if (navigator ((x:y):z) (0,0) (x1,y1))==Vazio && ((navigator ((x:y):z) (0,0) (x1, y1 + 1) ==Bloco) || (navigator ((x:y):z) (0,0) (x1, y1 + 1) ==Caixa)) then True
                                             else False
@

==Exemplo de utilização
>>>coordenadaInicialPossivel [[Vazio,Vazio,Vazio,Vazio,Bloco],[Porta,Vazio,Vazio,Vazio,Bloco],[Bloco,Vazio,Caixa,Vazio,Bloco],[Bloco,Bloco,Bloco,Bloco,Bloco]] (3,2)
True
-}
coordenadaInicialPossivel::Mapa            -- ^ mapa onde deve ser inserido o Personagem
                           ->Coordenadas   -- ^ posição onde o Jogador pretende colocar o Personagem
                           ->Bool          -- ^ resultado se é uma posição possível
coordenadaInicialPossivel [] _ = False
coordenadaInicialPossivel ((x:y):z) (x1,y1) =if (navigator ((x:y):z) (0,0) (x1,y1))==Vazio && ((navigator ((x:y):z) (0,0) (x1, y1 + 1) ==Bloco) || (navigator ((x:y):z) (0,0) (x1, y1 + 1) ==Caixa)) then True
                                             else False

{- | A função 'coordenadaPossivelCaixa' testa se uma coordenada dada pelo Jogador é uma coordenada possível para a coordenada inicial para colocar o personagem (este carrega uma caixa). Mapa é originado com constroiMapa da tarefa2 e Coordenadas é uma coordenada escolhida pelo Jogador.
     A função pode ser definida da seguinte forma:

@
coordenadaPossivelCaixa [] _ = False
coordenadaPossivelCaixa ((x:y):z) (x1,y1) =if ((navigator ((x:y):z) (0,0) (x1,y1))==Vazio && ((navigator ((x:y):z) (0,0) (x1, y1 + 1) ==Bloco) || (navigator ((x:y):z) (0,0) (x1, y1 + 1) ==Caixa)) && (navigator ((x:y):z) (0,0) (x1, y1 - 1)) == Vazio) then True
                                           else False
@

==Exemplo de utilização
>>>coordenadaPossivelCaixa [[Vazio,Vazio,Vazio,Vazio,Bloco],[Porta,Vazio,Vazio,Vazio,Bloco],[Bloco,Vazio,Caixa,Vazio,Bloco],[Bloco,Bloco,Bloco,Bloco,Bloco]] (3,2)
True
-}
coordenadaPossivelCaixa::Mapa            -- ^ mapa onde deve ser inserido o personagem
                         -> Coordenadas  -- ^ coordenadas onde o Jogador pretende colocar o personagem
                         -> Bool         -- ^ resultado se é uma posição possível
coordenadaPossivelCaixa [] _ = False
coordenadaPossivelCaixa ((x:y):z) (x1,y1) =if ((navigator ((x:y):z) (0,0) (x1,y1))==Vazio && ((navigator ((x:y):z) (0,0) (x1, y1 + 1) ==Bloco) || (navigator ((x:y):z) (0,0) (x1, y1 + 1) ==Caixa)) && (navigator ((x:y):z) (0,0) (x1, y1 - 1)) == Vazio) then True
                                           else False

{- | A função 'colocaJogador' origina uma string onde o personagem se insere no mapa. (x2,y2) é uma coordenada possivel e [(Peca,Coordenadas)] obtem-se da cMA do desconstroiMapa do mapa (funções da Tarefa 2).
     A função pode ser definida da seguinte forma:

@ 
colocaJogador [] _ = ""

colocaJogador [(x,(x1,y1))] (Jogador (x2,y2) Este False) |x1==x2 && y1==y2 = ">" ++colocaJogador [] (Jogador (x2,y2) Este False)
                                                         |x==Vazio =  " " ++colocaJogador [] (Jogador (x2,y2) Este False)
                                                         |x==Bloco =  "X" ++colocaJogador [] (Jogador (x2,y2) Este False)
                                                         |x==Caixa =  "C" ++colocaJogador [] (Jogador (x2,y2) Este False)
                                                         |x==Porta =  "P" ++colocaJogador [] (Jogador (x2,y2) Este False)

colocaJogador ((x,(x1,y1)):((x3,(x4,y4)):z)) (Jogador (x2,y2) Este False) |x1==x2 && y1==y2 = ">" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False) 
                                                                          |y1/=y4 =if x==Vazio then " " ++ "\n" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                                   else if x==Bloco then "X"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                                        else if x==Caixa then "C"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                                             else if x==Porta then "P"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                                                  else "" --impossivel
                                                                          |x==Vazio =  " " ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                          |x==Bloco =  "X" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                          |x==Caixa =  "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                          |x==Porta =  "P" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)

colocaJogador [(x,(x1,y1))] (Jogador (x2,y2) Oeste False)|x1==x2 && y1==y2 = "<" ++colocaJogador [] (Jogador (x2,y2) Oeste False)
                                                         |x==Vazio =  " " ++colocaJogador [] (Jogador (x2,y2) Oeste False)
                                                         |x==Bloco =  "X" ++colocaJogador [] (Jogador (x2,y2) Oeste False)
                                                         |x==Caixa =  "C" ++colocaJogador [] (Jogador (x2,y2) Oeste False)
                                                         |x==Porta =  "P" ++colocaJogador [] (Jogador (x2,y2) Oeste False)

colocaJogador ((x,(x1,y1)):((x3,(x4,y4)):z)) (Jogador (x2,y2) Oeste False) |x1==x2 && y1==y2 = "<" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                           |y1/=y4 =if x==Vazio then " " ++ "\n" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                                    else if x==Bloco then "X"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                                         else if x==Caixa then "C"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                                              else if x==Porta then "P"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                                                   else "" --impossivel
                                                                           |x==Vazio =  " " ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                           |x==Bloco =  "X" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                           |x==Caixa =  "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                           |x==Porta =  "P" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)

colocaJogador [(x,(x1,y1))] (Jogador (x2,y2) Este True) |x1==x2 && y1==y2 = ">" ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x1==x2 && y1 + 1==y2 = "C" ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x==Vazio =  " " ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x==Bloco =  "X" ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x==Caixa =  "C" ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x==Porta =  "P" ++colocaJogador [] (Jogador (x2,y2) Este True)

colocaJogador ((x,(x1,y1)):((x3,(x4,y4)):z)) (Jogador (x2,y2) Este True) |x1==x2 && y1==y2 = ">" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True) 
                                                                         |x1==x2 && y1 + 1==y2 = "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                         |y1/=y4 =if x==Vazio then " " ++ "\n" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                                  else if x==Bloco then "X"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                                       else if x==Caixa then "C"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                                            else if x==Porta then "P"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                                                 else "" --impossivel
                                                                         |x==Vazio =  " " ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                         |x==Bloco =  "X" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                         |x==Caixa =  "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                         |x==Porta =  "P" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)

colocaJogador [(x,(x1,y1))] (Jogador (x2,y2) Oeste True) |x1==x2 && y1==y2 = "<" ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x1==x2 && y1 + 1==y2 = "C" ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x==Vazio =  " " ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x==Bloco =  "X" ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x==Caixa =  "C" ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x==Porta =  "P" ++colocaJogador [] (Jogador (x2,y2) Oeste True)

colocaJogador ((x,(x1,y1)):((x3,(x4,y4)):z)) (Jogador (x2,y2) Oeste True) |x1==x2 && y1==y2 = "<" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True) 
                                                                         |x1==x2 && y1 + 1==y2 = "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                         |y1/=y4 =if x==Vazio then " " ++ "\n" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                                  else if x==Bloco then "X"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                                       else if x==Caixa then "C"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                                            else if x==Porta then "P"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                                                 else "" --impossivel
                                                                         |x==Vazio =  " " ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                         |x==Bloco =  "X" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                         |x==Caixa =  "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                         |x==Porta =  "P" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
@

==Exemplo de utilização
>>>colocaJogador [(Porta,(0,1)),(Bloco,(0,2)),(Bloco,(0,3)),(Bloco,(1,3)),(Caixa,(2,2)),(Bloco,(2,3)),(Bloco,(3,3)),(Bloco,(4,0)),(Bloco,(4,1)),(Bloco,(4,2)),(Bloco,(4,3))] (Jogador (3,2) Este True)
"P\nX\nXX\nC\nXX\nX\nX\nX"
-}
colocaJogador::[(Peca, Coordenadas)] -- ^ mapa onde deve ser colocado o personagem em forma de lista de peças/coordenadas ordenadas
               ->Jogador             -- ^ características do personagem no momento (coordenada, direção e se carrega ou não caixa)
               ->String              -- ^ string sem ser em modo de Jogo
colocaJogador [] _ = ""

colocaJogador [(x,(x1,y1))] (Jogador (x2,y2) Este False) |x1==x2 && y1==y2 = ">" ++colocaJogador [] (Jogador (x2,y2) Este False)
                                                         |x==Vazio =  " " ++colocaJogador [] (Jogador (x2,y2) Este False)
                                                         |x==Bloco =  "X" ++colocaJogador [] (Jogador (x2,y2) Este False)
                                                         |x==Caixa =  "C" ++colocaJogador [] (Jogador (x2,y2) Este False)
                                                         |x==Porta =  "P" ++colocaJogador [] (Jogador (x2,y2) Este False)

colocaJogador ((x,(x1,y1)):((x3,(x4,y4)):z)) (Jogador (x2,y2) Este False) |x1==x2 && y1==y2 = ">" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False) 
                                                                          |y1/=y4 =if x==Vazio then " " ++ "\n" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                                   else if x==Bloco then "X"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                                        else if x==Caixa then "C"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                                             else if x==Porta then "P"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                                                  else "" --impossivel
                                                                          |x==Vazio =  " " ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                          |x==Bloco =  "X" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                          |x==Caixa =  "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)
                                                                          |x==Porta =  "P" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este False)

colocaJogador [(x,(x1,y1))] (Jogador (x2,y2) Oeste False)|x1==x2 && y1==y2 = "<" ++colocaJogador [] (Jogador (x2,y2) Oeste False)
                                                         |x==Vazio =  " " ++colocaJogador [] (Jogador (x2,y2) Oeste False)
                                                         |x==Bloco =  "X" ++colocaJogador [] (Jogador (x2,y2) Oeste False)
                                                         |x==Caixa =  "C" ++colocaJogador [] (Jogador (x2,y2) Oeste False)
                                                         |x==Porta =  "P" ++colocaJogador [] (Jogador (x2,y2) Oeste False)

colocaJogador ((x,(x1,y1)):((x3,(x4,y4)):z)) (Jogador (x2,y2) Oeste False) |x1==x2 && y1==y2 = "<" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                           |y1/=y4 =if x==Vazio then " " ++ "\n" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                                    else if x==Bloco then "X"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                                         else if x==Caixa then "C"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                                              else if x==Porta then "P"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                                                   else "" --impossivel
                                                                           |x==Vazio =  " " ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                           |x==Bloco =  "X" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                           |x==Caixa =  "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)
                                                                           |x==Porta =  "P" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste False)

colocaJogador [(x,(x1,y1))] (Jogador (x2,y2) Este True) |x1==x2 && y1==y2 = ">" ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x1==x2 && y1 + 1==y2 = "C" ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x==Vazio =  " " ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x==Bloco =  "X" ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x==Caixa =  "C" ++colocaJogador [] (Jogador (x2,y2) Este True)
                                                        |x==Porta =  "P" ++colocaJogador [] (Jogador (x2,y2) Este True)

colocaJogador ((x,(x1,y1)):((x3,(x4,y4)):z)) (Jogador (x2,y2) Este True) |x1==x2 && y1==y2 = ">" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True) 
                                                                         |x1==x2 && y1 + 1==y2 = "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                         |y1/=y4 =if x==Vazio then " " ++ "\n" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                                  else if x==Bloco then "X"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                                       else if x==Caixa then "C"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                                            else if x==Porta then "P"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                                                 else "" --impossivel
                                                                         |x==Vazio =  " " ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                         |x==Bloco =  "X" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                         |x==Caixa =  "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)
                                                                         |x==Porta =  "P" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Este True)

colocaJogador [(x,(x1,y1))] (Jogador (x2,y2) Oeste True) |x1==x2 && y1==y2 = "<" ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x1==x2 && y1 + 1==y2 = "C" ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x==Vazio =  " " ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x==Bloco =  "X" ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x==Caixa =  "C" ++colocaJogador [] (Jogador (x2,y2) Oeste True)
                                                        |x==Porta =  "P" ++colocaJogador [] (Jogador (x2,y2) Oeste True)

colocaJogador ((x,(x1,y1)):((x3,(x4,y4)):z)) (Jogador (x2,y2) Oeste True) |x1==x2 && y1==y2 = "<" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True) 
                                                                         |x1==x2 && y1 + 1==y2 = "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                         |y1/=y4 =if x==Vazio then " " ++ "\n" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                                  else if x==Bloco then "X"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                                       else if x==Caixa then "C"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                                            else if x==Porta then "P"++ "\n"++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                                                 else "" --impossivel
                                                                         |x==Vazio =  " " ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                         |x==Bloco =  "X" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                         |x==Caixa =  "C" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)
                                                                         |x==Porta =  "P" ++colocaJogador ((x3,(x4,y4)):z) (Jogador (x2,y2) Oeste True)

{- | A função 'comprimentoMapa' diz qual o comprimento do mapa.
     A função pode ser definida da seguinte forma:

@
comprimentoMapa (x:z) = length x
@

==Exemplo de utilização
comprimentoMapa [[Vazio,Vazio,Vazio,Vazio,Bloco],[Porta,Vazio,Vazio,Vazio,Bloco],[Bloco,Vazio,Caixa,Vazio,Bloco],[Bloco,Bloco,Bloco,Bloco,Bloco]]
4
-}
comprimentoMapa::Mapa   -- ^ mapa do qual se pretende saber o comprimento
                 ->Int  -- ^ comprimento do mapa
comprimentoMapa (x:z) = length x

{- | A função 'alturaMapa' diz qual a altura do mapa.
     A função pode ser definida da seguinte forma:

@
alturaMapa (x:z) = length (x:z)
@

==Exemplo de utilização
alturaMapa [[Vazio,Vazio,Vazio,Vazio,Bloco],[Porta,Vazio,Vazio,Vazio,Bloco],[Bloco,Vazio,Caixa,Vazio,Bloco],[Bloco,Bloco,Bloco,Bloco,Bloco]]
3
-}
alturaMapa::Mapa   -- ^ mapa do qual se pretende saber a altura
            ->Int  -- ^ comprimento do mapa
alturaMapa (x:z) = length (x:z)

-- Função que devolve a peça na coordenada (xp,yp)   input de x,y tem que ser smpre (0,0) para começar a ver desde o inicio do mapa
navigator :: Mapa -> Coordenadas -> Coordenadas -> Peca  
navigator [] _ _ = Vazio   --(0,0) (4 , 5)
navigator (((peca):ti):te) (x,y) (xp,yp)
  | x == xp && y == yp = peca
  | ti /= [] = navigator (ti:te) (x+1,y) (xp,yp)
  | otherwise = navigator te (0,y+1) (xp,yp)









































