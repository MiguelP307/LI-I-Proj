module Tarefa4_2021li1g003_Spec where

import Test.HUnit
import LI12122
import Tarefa3_2021li1g003
import Tarefa4_2021li1g003
import Fixtures

testsT4 =
  test
    [ "Tarefa 4 - Teste Move Oeste:" ~: Jogo mapa1_construido (Jogador (3, 2) Oeste False) ~=?  moveJogador mapa1_e1 AndarEsquerda
    , "Tarefa 4 - Teste Move Este:" ~: Jogo mapa1_construido (Jogador (4, 2) Este False) ~=?  moveJogador mapa1_e2 AndarDireita
    , "Tarefa 4 - Teste Move Alterar direção Este:" ~: mapa1_e3 ~=? moveJogador mapa1_e5 AndarEsquerda
    , "Tarefa 4 - Teste Move Alterar direção Oeste:" ~: mapa1_e5 ~=? moveJogador mapa1_e3 AndarDireita
    , "Tarefa 4 - Teste Move Queda Oeste s/ caixa:" ~: Jogo mapa1_construido (Jogador (1, 3) Oeste False) ~=? moveJogador mapa1_e4 AndarEsquerda
    , "Tarefa 4 - Teste Move Queda Este s/ caixa:" ~: mapa1_e2 ~=? moveJogador mapa1_e4 AndarDireita
    , "Tarefa 4 - Teste Move Queda do Jogador s/caixa Oeste:" ~: Jogo mapa1_construido (Jogador (1,3) Oeste False) ~=? moveJogador mapa1_e4 AndarEsquerda
    , "Tarefa 4 - Teste Move Queda do Jogador s/caixa Este:" ~: Jogo mapa1_construido (Jogador (3,2) Este False) ~=? moveJogador mapa1_e4 AndarDireita
    , "Tarefa 4 - Teste Move Trepar de costas:" ~: mapa1_e2 ~=? moveJogador mapa1_e2 Trepar
    , "Tarefa 4 - Teste Move Trepar no Vazio:" ~: mapa1_e4 ~=? moveJogador mapa1_e4 Trepar
    , "Tarefa 4 - Teste Move Trepar 2 bloco de altura:" ~: Jogo mapa1_construido (Jogador(1,3) Este False) ~=? moveJogador (Jogo mapa1_construido (Jogador (1,3) Este False)) Trepar
    , "Tarefa 4 - Teste Move Trepar em caixa:" ~: mapa1_e1 ~=? moveJogador mapa1_e3 Trepar
    , "Tarefa 4 - Teste Move Trepar numa parede com 1 buraco:" ~: Jogo mapa4_construido (Jogador (1,1) Oeste False) ~=? moveJogador mapa4_e1 Trepar
    , "Tarefa 4 - Teste Move Andar c/ caixa contra Bloco:" ~: mapa5_e1 ~=? moveJogador mapa5_e1 AndarEsquerda
    , "Tarefa 4 - Teste Move Pousar caixa contra Bloco:" ~: mapa5_e1 ~=? moveJogador mapa5_e1 InterageCaixa    
    , "Tarefa 4 - Teste Move InterageCaixa Bloqueada:" ~: mapa2_e1 ~=? moveJogador mapa2_e1 InterageCaixa
    , "Tarefa 4 - Teste Move InterageCaixa Bloqueada (Player):" ~: mapa3_e1 ~=? moveJogador mapa3_e1 InterageCaixa
    , "Tarefa 4 - Teste Move InterageCaixa Pousar:" ~: mapa1_e3 ~=? moveJogador 
    (Jogo [ [Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Bloco],
          [Vazio, Vazio, Vazio, Vazio, Vazio, Bloco, Bloco],
          [Vazio, Vazio, Bloco, Vazio, Vazio, Caixa, Bloco],
          [Porta, Vazio, Bloco, Bloco, Vazio, Vazio, Bloco],
          [Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco]]
           (Jogador (5,3) Oeste True)) InterageCaixa
    , "Tarefa 4 - Teste Movimentos InterageCaixa Pousar em cima de Bloco:" ~:
    (Jogo [[Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Bloco],
          [Vazio, Vazio, Vazio, Vazio, Vazio, Bloco, Bloco],
          [Vazio, Vazio, Bloco, Caixa, Vazio, Vazio, Bloco],
          [Porta, Vazio, Bloco, Bloco, Vazio, Vazio, Bloco],
          [Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco]]
           (Jogador (4,3) Oeste False)) ~=? correrMovimentos mapa1_e3 [InterageCaixa,AndarEsquerda,InterageCaixa]
    , "Tarefa 4 - Teste de Movimentos Queda da caixa apos pousar:" ~: 
    (Jogo [[Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Bloco],
          [Vazio, Vazio, Vazio, Vazio, Vazio, Bloco, Bloco],
          [Vazio, Vazio, Bloco, Vazio, Vazio, Vazio, Bloco],
          [Porta, Caixa, Bloco, Bloco, Vazio, Vazio, Bloco],
          [Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco]]
           (Jogador (2,1) Oeste False)) ~=? correrMovimentos mapa1_e3 [InterageCaixa,AndarEsquerda,Trepar,Trepar,InterageCaixa] 
    , "Tarefa 4 - Teste de movimentos mapa1_e3 InteragirCaixa/Trepar/AndarEsquerda/Queda c/ caixa:" ~: Jogo mapa1_construido_test5 (Jogador (1,3) Oeste True) ~=? correrMovimentos mapa1_e3 [InterageCaixa,AndarEsquerda,Trepar,Trepar,AndarEsquerda]
    ]