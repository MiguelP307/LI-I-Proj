module Tarefa2_2021li1g003_Spec where

import Data.List (sort)
import Test.HUnit
import LI12122
import Tarefa2_2021li1g003
import Fixtures

testsT2 =
  test
    [ "Tarefa 2 - Teste Construir Mapa mapa1" ~: mapa1_construido ~=? constroiMapa mapa1
    , "Tarefa 2 - Teste Construir Mapa vazio" ~: [] ~=? constroiMapa []
    , "Tarefa 2 - Teste Desconstruir Mapa mapa1 ja construido" ~: sort mapa1 ~=?  sort (desconstroiMapa mapa1_construido)
    , "Tarefa 2 - Teste Desconstruir Mapa vazio" ~: [] ~=? desconstroiMapa []
    , "Tarefa 2 - Teste Identidade do mapa1" ~: sort mapa1 ~=?  sort (desconstroiMapa (constroiMapa mapa1))
    , "Tarefa 2 - Teste Identidade mapa1 ja Construido" ~: mapa1_construido ~=?  constroiMapa (desconstroiMapa mapa1_construido)
    , "Tarefa 2 - Teste Construir Sobrepor Peças" ~: constroiMapa [(Bloco,(0,0)),(Porta, (7, 4))] ~=?  constroiMapa [(Bloco,(0,0)), (Porta, (7, 4)), (Porta, (7, 4))]
    ]