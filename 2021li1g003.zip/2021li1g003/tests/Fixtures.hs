module Fixtures where

import LI12122


-- Mapa que cumpre todos os requesitos para que seja validado com sucesso
mapa1 :: [(Peca, Coordenadas)]
mapa1 =
  [ (Porta, (0, 3)),
    (Bloco, (0, 4)),
    (Bloco, (1, 4)),
    (Bloco, (2, 4)),
    (Bloco, (3, 4)),
    (Bloco, (4, 4)),
    (Caixa, (4, 3)),
    (Bloco, (5, 4)),
    (Bloco, (6, 4)),
    (Bloco, (6, 3)),
    (Bloco, (6, 2)),
    (Bloco, (6, 1)),
    (Bloco, (6, 0)),
    (Bloco, (2, 2)),
    (Bloco, (2, 3)),
    (Bloco, (3, 3)),
    (Bloco, (5, 1))
  ]

-- [CASO] Caixa Flutuante
mapa2 :: [(Peca,Coordenadas)]
mapa2 =
  [ (Caixa, (0,0)),
    (Bloco, (0,2)),
    (Bloco, (1,2)),
    (Porta, (1,1))
  ]

-- [CASO] Duas Portas
mapa3 :: [(Peca,Coordenadas)]
mapa3 =
  [ (Bloco, (0,2)),
    (Bloco, (1,2)),
    (Porta, (1,1)),
    (Porta, (0,1))
  ]

-- [CASO] Nenhum espaço vazio
mapa4 :: [(Peca,Coordenadas)]
mapa4 =
  [ (Bloco, (0,2)),
    (Bloco, (1,2)),
    (Bloco, (1,1)),
    (Porta, (0,1)),
    (Bloco, (0,0)),
    (Bloco, (1,0))
  ]

-- [CASO] Sem chão
mapa5 :: [(Peca,Coordenadas)]
mapa5 =
  [ (Bloco, (0,2)),
    (Bloco, (1,2)),
    (Bloco, (3,2)),
    (Porta, (0,1))
  ]

mapa1_construido :: Mapa
mapa1_construido =
  [ [Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Bloco],
    [Vazio, Vazio, Vazio, Vazio, Vazio, Bloco, Bloco],
    [Vazio, Vazio, Bloco, Vazio, Vazio, Vazio, Bloco],
    [Porta, Vazio, Bloco, Bloco, Caixa, Vazio, Bloco],
    [Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco]
  ]


-- Mapa de teste para a tarefa4, podem não ser necessariamente validos para niveis
mapa1_construido_test5 :: Mapa
mapa1_construido_test5 =
  [ [Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Bloco],
    [Vazio, Vazio, Vazio, Vazio, Vazio, Bloco, Bloco],
    [Vazio, Caixa, Bloco, Vazio, Vazio, Vazio, Bloco],
    [Porta, Vazio, Bloco, Bloco, Vazio, Vazio, Bloco],
    [Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco]
  ]
 
 -- [CASO] Bloco em cima da Caixa  
mapa2_construido :: Mapa
mapa2_construido =
   [ [Vazio,Vazio,Vazio,Bloco],
      [Vazio,Bloco,Vazio,Bloco],
      [Porta,Caixa,Vazio,Bloco],
      [Bloco,Bloco,Bloco,Bloco]
   ]

-- [CASO] Bloco em cima do jogador
mapa3_construido :: Mapa
mapa3_construido =
   [ [Vazio,Vazio,Vazio,Bloco],
     [Vazio,Vazio,Bloco,Bloco],
     [Porta,Caixa,Vazio,Bloco],
     [Bloco,Bloco,Bloco,Bloco]
   ]

-- [CASO] Jogador Trepar numa parede com 1 abertura de 1 bloco de altura
mapa4_construido :: Mapa
mapa4_construido =
   [ [Vazio,Bloco,Vazio,Bloco],
     [Vazio,Vazio,Vazio,Bloco],
     [Porta,Bloco,Vazio,Bloco],
     [Bloco,Bloco,Bloco,Bloco]
   ]
 
 -- [CASO] Bloco a atrapalhar caixa
mapa5_construido :: Mapa
mapa5_construido =
   [ [Vazio,Vazio,Vazio,Bloco],
     [Vazio,Bloco,Caixa,Bloco],
     [Porta,Vazio,Vazio,Bloco],
     [Bloco,Bloco,Bloco,Bloco]
   ]
 


mapa1_e1 :: Jogo
mapa1_e1 = Jogo mapa1_construido (Jogador (4, 2) Oeste False)

mapa1_e2 :: Jogo
mapa1_e2 = Jogo mapa1_construido (Jogador (3, 2) Este False)

mapa1_e3 :: Jogo
mapa1_e3 = Jogo mapa1_construido (Jogador (5, 3) Oeste False)

mapa1_e4 :: Jogo
mapa1_e4 = Jogo mapa1_construido (Jogador (2, 1) Oeste False)

mapa1_e5 :: Jogo
mapa1_e5 = Jogo mapa1_construido (Jogador (5, 3) Este False)

mapa2_e1 :: Jogo
mapa2_e1 = Jogo mapa2_construido (Jogador (2,2) Oeste False)

mapa3_e1 :: Jogo
mapa3_e1 = Jogo mapa3_construido (Jogador (2,2) Oeste False)

mapa4_e1 :: Jogo
mapa4_e1 = Jogo mapa4_construido (Jogador (2,2) Oeste False)

mapa5_e1 :: Jogo
mapa5_e1 = Jogo mapa5_construido (Jogador (2,2) Oeste True)