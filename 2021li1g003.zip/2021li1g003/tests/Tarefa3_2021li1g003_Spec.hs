module Tarefa3_2021li1g003_Spec where

import Test.HUnit
import Tarefa3_2021li1g003
import Fixtures

testsT3 =
  test
    [ "Tarefa 3 - Teste Imprime Jogo mapa1_e1" ~: "      X \n     XX \n  X < X \nP XXC X \nXXXXXXX" ~=?  show mapa1_e1
    , "Tarefa 3 - Teste Imprime Jogo mapa1_e2" ~: "      X \n     XX \n  X>  X \nP XXC X \nXXXXXXX" ~=?  show mapa1_e2
    ]