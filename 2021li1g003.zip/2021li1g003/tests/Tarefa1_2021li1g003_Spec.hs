module Tarefa1_2021li1g003_Spec where

import Test.HUnit
import LI12122
import Tarefa1_2021li1g003
import Fixtures

--mapa novo também cumpre requesitos para ser validado
mapanovo :: [(Peca, Coordenadas)]
mapanovo =
  [ (Porta, (0, 2)),
    (Bloco, (0, 3)),
    (Bloco, (1, 3)),
    (Bloco, (2, 2)),
    (Bloco, (2, 3)),
    (Caixa, (3, 1)),
    (Bloco, (3, 2)),
    (Bloco, (4, 2))
  ]
  
-- Tarefa 1
testsT1 =
  test
    [ "Tarefa 1 - Teste Valida Mapa mapa1" ~: validaPotencialMapa mapa1 ~=? True
    , "Tarefa 1 - Teste Valida Mapa mapa2" ~: validaPotencialMapa mapa2 ~=? False
    , "Tarefa 1 - Teste Valida Mapa mapa3" ~: validaPotencialMapa mapa3 ~=? False
    , "Tarefa 1 - Teste Valida Mapa mapa4" ~: validaPotencialMapa mapa4 ~=? False
    , "Tarefa 1 - Teste Valida Mapa mapa5" ~: validaPotencialMapa mapa5 ~=? False
    , "Tarefa 1 - Teste Valida Mapa vazio" ~: validaPotencialMapa [] ~=? False
    , "Tarefa 1 - Teste Valida Mapa com 2 pecas na mesma posição" ~: validaPotencialMapa [(Bloco, (0,0)), (Caixa, (1,0)), (Porta, (3,0))] ~=?  False
    , "Tarefa 1 - Teste Valida Mapa mapanovo" ~: validaPotencialMapa mapanovo ~=? True
    ]
